package base;

import java.io.File;
import java.time.Duration;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;

public class TestBase {
    protected WebDriver driver;
    protected final String baseUrl = System.getenv().getOrDefault("BASE_URL", "https://www.saucedemo.com");
    protected final String standardUser = System.getenv().getOrDefault("STANDARD_USER", "standard_user");
    protected final String lockedUser = System.getenv().getOrDefault("LOCKED_USER", "locked_out_user");
    protected final String password = System.getenv().getOrDefault("PASSWORD", "secret_sauce");

    @BeforeMethod
    public void setUp() {
        ChromeOptions options = new ChromeOptions();
        if (Boolean.parseBoolean(System.getenv().getOrDefault("HEADLESS", "false"))) {
            options.addArguments("--headless=new");
        }
        driver = new ChromeDriver(options);
        driver.manage().timeouts().implicitlyWait(Duration.ZERO);
        driver.manage().window().maximize();
    }

    @AfterMethod(alwaysRun = true)
    public void tearDown(ITestResult result) {
        if (driver != null && !result.isSuccess()) {
            try {
                File dir = new File("target/failure-screenshots");
                dir.mkdirs();
                File dest = new File(dir, result.getMethod().getMethodName() + ".png");
                ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE)
                    .renameTo(dest);
            } catch (Exception ignored) { }
        }
        if (driver != null) driver.quit();
    }
}
